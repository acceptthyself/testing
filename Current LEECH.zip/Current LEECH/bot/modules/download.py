from pyrogram import filters
from .. import LOGGER, qbittorrent_client
from bot.helper.telegram_helper.bot_commands import BotCommands
from bot.helper.telegram_helper.message_utils import send_message, edit_message, delete_message, send_status_message
from bot.helper.ext_utils.bot_utils import new_task, sync_to_async
from bot.helper.ext_utils.status_utils import get_readable_file_size
from bot.helper.mirror_leech_utils.download_utils.qbit_download import add_qb_torrent
from ..helper.telegram_helper.filters import CustomFilters
from pyrogram.handlers import MessageHandler
from pyrogram.filters import command
import time
import asyncio  # Import asyncio

@new_task
async def auto_download(client, message):
    """
    Command format: /download movie_name quality
    Example: /download Inception 720p
    """
    args = message.text.split(' ', 1)
    if len(args) <= 1:
        await send_message(message, "Please provide a movie name!\nFormat: /download movie_name quality")
        return

    search_query = args[1]

    class DummyListener:
        def __init__(self, link, progress_msg):
            # NOTE: Initially link is set to the torrent URL/magnet.
            # After the torrent is added, we update this to the actual torrent hash.
            self.link = link  
            self.message = progress_msg
            self.mid = f"download_{progress_msg.chat.id}_{progress_msg.id}"
            # Required attributes for download system
            self.select = False
            self.multi = 1
            self.is_cancelled = False
            self.stop_duplicate = False
            self.seed = False
            self.is_super_chat = False
            self.name = None  # For filename
            self.subname = None  # For subtitle name
            self.tag = None  # For user tags
            self.upload_details = {}  # For upload details
            self.isPrivate = progress_msg.chat.type == "private"
            self.user_id = progress_msg.from_user.id if progress_msg.from_user else None
            self.chat_id = progress_msg.chat.id
            self.leech = True  # Since we want to leech/upload to Telegram
            self.dir = 'downloads'  # Default download directory
            self.size = 0  # Total size
            self._processed_bytes = 0  # Processed bytes
            self._start_time = time.time()  # Start time for speed calculation
            self.progress = 0  # Download progress percentage

        def processed_bytes(self):
            return self._processed_bytes

        def speed_raw(self):
            return self._processed_bytes / (time.time() - self._start_time)

        def speed(self):
            return f"{get_readable_file_size(self.speed_raw())}/s"

        def update_progress(self, processed_bytes, total_size):
            self._processed_bytes = processed_bytes
            self.size = total_size
            if total_size > 0:
                self.progress = (self._processed_bytes / total_size) * 100
            else:
                self.progress = 0

        async def display_progress(self):
            bar_length = 20  # Length of the progress bar
            filled_length = int(bar_length * self.progress // 100)
            bar = '█' * filled_length + '-' * (bar_length - filled_length)
            msg = f"[{bar}] {self.progress:.2f}%\n"
            msg += f"Processed: {get_readable_file_size(self.processed_bytes())}\n"
            msg += f"Size: {get_readable_file_size(self.size)}\n"
            msg += f"Speed: {self.speed()}\n"
            # Add ETA and other details if available
            await edit_message(self.message, msg)

        async def on_download_error(self, error):
            await edit_message(self.message, f"Download Error: {error}")

        async def on_download_start(self):
            pass

        async def on_upload_start(self):
            pass

        async def on_download_complete(self):
            await edit_message(self.message, "✅ Download completed! Starting upload...")

        async def on_upload_complete(self, link, size, files, folders, typ):
            msg = f"✅ Upload completed!\n\n"
            msg += f"📁 Size: {get_readable_file_size(size)}\n"
            msg += f"📂 Files: {files}\n"
            if folders: 
                msg += f"📁 Folders: {folders}\n"
            if link: 
                msg += f"🔗 Link: {link}\n"
            await edit_message(self.message, msg)

        async def onUploadError(self, error):
            await edit_message(self.message, f"❌ Upload Error: {error}")

        async def update(self):
            """Call this periodically to update and display progress."""
            try:
                # Use the torrent hash stored in self.link to get torrent info.
                torrent_info = await sync_to_async(qbittorrent_client.torrents_info, torrent_hashes=self.link)
                if not torrent_info or len(torrent_info) == 0:
                    LOGGER.error(f"No torrent info returned for torrent hash: {self.link}")
                    return
                info = torrent_info[0]  # Safe to access first element only if list is not empty
                self.update_progress(info.completed, info.size)
                await self.display_progress()
            except Exception as e:
                LOGGER.error(f"Error getting torrent info for {self.link}: {e}")

    try:
        status_msg = await send_message(message, "🔍 Searching for your movie...")

        # Start the search using qBittorrent's search plugin (YTS only)
        search = await sync_to_async(
            qbittorrent_client.search_start,
            pattern=search_query,
            plugins="yts_mx",  # Only use YTS plugin
            category="all"
        )
        search_id = search.id

        # Wait until the search completes
        while True:
            result_status = await sync_to_async(qbittorrent_client.search_status, search_id=search_id)
            status_val = result_status[0].status
            if status_val != "Running":
                break
            await edit_message(status_msg, "🔍 Searching... Please wait!")
            time.sleep(2)

        # Retrieve the search results with a defined limit
        dict_search_results = await sync_to_async(
            qbittorrent_client.search_results,
            search_id=search_id,
            limit=50
        )

        if dict_search_results.total == 0:
            await edit_message(status_msg, "❌ No results found! Please check your search term.")
            return

        if not dict_search_results.results:
            await edit_message(status_msg, "❌ No results found with seeders! Please try a different search term.")
            return

        # Select the torrent with the most seeders
        selected_torrent = max(dict_search_results.results, key=lambda x: x.nbSeeders)

        # Prepare the movie information message
        info_msg = f"🎬 Found: {selected_torrent.fileName}\n"
        info_msg += f"📥 Size: {get_readable_file_size(selected_torrent.fileSize)}\n"
        info_msg += f"⚡ Seeds: {selected_torrent.nbSeeders} | 📥 Leechers: {selected_torrent.nbLeechers}\n"

        await edit_message(status_msg, info_msg)

        # Create our DummyListener; note the torrent URL/magnet is used initially.
        listener = DummyListener(selected_torrent.fileUrl, status_msg)
        listener.name = selected_torrent.fileName  # Set the name from the torrent

        # Initiate the download via qBittorrent.
        # Inside add_qb_torrent, the listener.link gets updated to the actual torrent hash.
        await add_qb_torrent(listener, selected_torrent.fileUrl, 1.5, 3600)

    except Exception as e:
        await edit_message(status_msg, f"An error occurred: {str(e)}")
    finally:
        # Clean up the search.
        if 'search_id' in locals():
            await sync_to_async(qbittorrent_client.search_delete, search_id=search_id)
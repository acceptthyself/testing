from aiofiles.os import remove, path as aiopath
from asyncio import sleep
from time import time
import httpx # Add httpx
from bot.helper.ext_utils.db_handler import database # Import database
from bot.core.config_manager import Config # Import Config
from ..mirror_leech_utils.telegram_uploader import TelegramUploader
import json # For payload
from config import *

from ... import (
    task_dict,
    task_dict_lock,
    intervals,
    qbittorrent_client,
    qb_torrents,
    qb_listener_lock,
    LOGGER,
)
from ...core.config_manager import Config
from ..ext_utils.bot_utils import new_task, sync_to_async
from ..ext_utils.files_utils import clean_unwanted
from ..ext_utils.status_utils import get_readable_time, get_task_by_gid
from ..ext_utils.task_manager import stop_duplicate_check
from ..mirror_leech_utils.status_utils.qbit_status import QbittorrentStatus
from ..telegram_helper.message_utils import update_status_message


async def _remove_torrent(hash_, tag):
    await sync_to_async(
        qbittorrent_client.torrents_delete, torrent_hashes=hash_, delete_files=True
    )
    async with qb_listener_lock:
        if tag in qb_torrents:
            del qb_torrents[tag]
    await sync_to_async(qbittorrent_client.torrents_delete_tags, tags=tag)


# --- Modify _on_download_error ---
@new_task
async def _on_download_error(err, tor, button=None):
    request_id = tor.tags # Assuming tag is the request_id
    display_name = tor.name
    ext_hash = tor.hash
    is_api_task = False

    if request_id:
        api_request_data = await database.get_api_request(request_id)
        if api_request_data:
            is_api_task = True
            LOGGER.info(f"Download Error for API Task: {display_name} (Request ID: {request_id}), Error: {err}")
            # --- Call Webhook for API Task Failure ---
            await _send_webhook_notification(request_id, "failed", display_name, error_message=err)
            # --- End Webhook Call ---
        else:
             LOGGER.info(f"Download Error for Task: {display_name} (Tag/Hash: {request_id or ext_hash}), Error: {err}")
    else:
        LOGGER.info(f"Download Error for Task: {display_name} (Hash: {ext_hash}), Error: {err}")

    # Original listener logic for tasks started via bot commands
    if not is_api_task:
        if task := await get_task_by_gid(ext_hash[:12]):
            # Check if listener exists before calling methods
            if hasattr(task, 'listener') and task.listener:
                 await task.listener.on_download_error(err, button)
            else:
                 LOGGER.warning(f"Task {ext_hash[:12]} found but has no listener for on_download_error.")

    # Cleanup qBittorrent and internal tracking (always do this on error)
    try:
        await sync_to_async(qbittorrent_client.torrents_pause, torrent_hashes=ext_hash)
        await sleep(0.5)
        await _remove_torrent(ext_hash, request_id or f"error_{ext_hash}")
    except Exception as cleanup_err:
         LOGGER.error(f"Error during cleanup for errored task {ext_hash} (Tag: {request_id}): {cleanup_err}")


@new_task
async def _on_seed_finish(tor):
    ext_hash = tor.hash
    LOGGER.info(f"Cancelling Seed: {tor.name}")
    if task := await get_task_by_gid(ext_hash[:12]):
        msg = f"Seeding stopped with Ratio: {round(tor.ratio, 3)} and Time: {get_readable_time(tor.seeding_time)}"
        await task.listener.on_upload_error(msg)
    await _remove_torrent(ext_hash, tor.tags)


@new_task
async def _stop_duplicate(tor):
    if task := await get_task_by_gid(tor.hash[:12]):
        if task.listener.stop_duplicate:
            task.listener.name = tor.content_path.rsplit("/", 1)[-1].rsplit(".!qB", 1)[
                0
            ]
            msg, button = await stop_duplicate_check(task.listener)
            if msg:
                _on_download_error(msg, tor, button)


# --- Modify _on_download_complete ---
@new_task
async def _on_download_complete(tor):
    request_id = tor.tags # Assuming tag is the request_id
    display_name = tor.name
    ext_hash = tor.hash
    is_api_task = False
    api_request_data = None

    # Check if this task originated from the API
    if request_id:
        api_request_data = await database.get_api_request(request_id)
        if api_request_data:
            is_api_task = True
            LOGGER.info(f"Download Complete for API Task: {display_name} (Request ID: {request_id})")
        else:
            LOGGER.info(f"Download Complete for Task: {display_name} (Tag/Hash: {request_id or ext_hash})")
    else:
        LOGGER.info(f"Download Complete for Task: {display_name} (Hash: {ext_hash})")

    # --- Upload Logic ---
    upload_success = False
    upload_error = None
    uploaded_message_link = None
    # Use the configured default dump chat for API tasks
    upload_destination_chat_id = getattr(Config, 'LEECH_DUMP_CHAT', None) if is_api_task else None

    if is_api_task:
        if not upload_destination_chat_id:
             upload_error = "LEECH_DUMP_CHAT not configured in Leech Bot."
             LOGGER.error(upload_error)
        else:
             try:
                  # Create the minimal listener context for the uploader
                  class ApiTaskListener:
                       def __init__(self, user_id, request_id, name):
                            self.user_id = user_id
                            self.mid = request_id
                            self.name = name
                            self.is_cancelled = False
                            self.is_super_chat = True # Assume dump chat is group/channel
                            self.up_dest = None # <<< LET UPLOADER USE DEFAULT DUMP CHAT
                            self.chat_thread_id = None
                            self.user_dict = {} # Use bot defaults
                            self.thumb = None # Use bot defaults
                            self.extension_filter = [] # Use bot defaults
                            self.user_transmission = False # Use bot client
                            self.mixed_leech = False
                            self.as_doc = False # Use bot defaults
                            self.thumbnail_layout = None
                            self.screen_shots = 0
                            # Add dummy message object if uploader absolutely needs it
                            # self.message = type('obj', (object,), {'id': request_id, 'chat': type('obj', (object,), {'id': upload_destination_chat_id})()})()

                       async def on_upload_error(self, err): LOGGER.error(f"Uploader Error for {self.mid}: {err}")
                       async def on_upload_complete(self, link, files_dict, total_files, total_corrupt): pass

                  listener_for_upload = ApiTaskListener(api_request_data['user_id'], request_id, display_name)
                  uploader = TelegramUploader(listener=listener_for_upload, path=tor.content_path)

                  LOGGER.info(f"API Task {request_id}: Attempting upload via TelegramUploader to default dump chat from path {tor.content_path}")
                  await uploader.upload() # Start the upload
                  LOGGER.info(f"API Task {request_id}: uploader.upload() call finished.")

                  # Refined status check (still needs uploader improvements ideally)
                  if not listener_for_upload.is_cancelled and uploader._corrupted == 0:
                       upload_success = True
                       # uploaded_message_link = uploader.get_last_message_link() # Get link if implemented
                       LOGGER.info(f"Upload successful for API Task {request_id} to {upload_destination_chat_id}")
                  else:
                       upload_error = uploader._error or "Upload failed or was cancelled."
                       LOGGER.error(f"Upload failed for API Task {request_id}: {upload_error}")

             except Exception as e:
                  upload_error = f"Exception during upload: {e}"
                  LOGGER.error(f"Upload exception for API Task {request_id}: {e}", exc_info=True)

        # --- Send Webhook (Only for API tasks) ---
        if is_api_task:
             if upload_success:
                  await _send_webhook_notification(
                       request_id, "success", display_name,
                       uploaded_to_chat_id=upload_destination_chat_id, # Report where it went
                       uploaded_message_link=uploaded_message_link
                  )
             else:
                  await _send_webhook_notification(
                       request_id, "failed", display_name,
                       error_message=f"Upload failed: {upload_error}"
                  )
        # --- End Webhook ---

    # --- Original Listener Logic (for non-API tasks) ---
    else:
        task = await get_task_by_gid(ext_hash[:12])
        if task:
             # Check if listener exists before calling methods
             if hasattr(task, 'listener') and task.listener:
                  if not task.listener.seed:
                       await sync_to_async(qbittorrent_client.torrents_pause, torrent_hashes=ext_hash)
                  if task.listener.select:
                       await clean_unwanted(task.listener.dir)
                       # ... (original file removal logic for select mode) ...
                  await task.listener.on_download_complete() # Triggers upload for regular tasks
                  if intervals["stopAll"]: return
             else:
                  LOGGER.warning(f"Task {ext_hash[:12]} found but has no listener for on_download_complete.")
                  # Decide if you should clean up here if no listener?
                  await _remove_torrent(ext_hash, request_id or ext_hash[:12])
                  return # Stop processing if no listener

             # Seeding logic for regular tasks
             if task.listener.seed and not task.listener.is_cancelled:
                  # ... (original seeding logic, ensure tag_to_check is correct) ...
                  tag_to_check = request_id or task.listener.tag or ext_hash[:12]
                  # ... rest of seeding logic ...
                  pass
             else:
                  await _remove_torrent(ext_hash, request_id or task.listener.tag or ext_hash[:12])
        else:
             LOGGER.warning(f"Orphan download completed. Hash: {ext_hash}, Tag: {request_id}. Cleaning up.")
             await _remove_torrent(ext_hash, request_id or ext_hash[:12])
             return

    # --- Seeding / Cleanup Logic (Adjusted) ---
    # Cleanup for API tasks happens after upload attempt (success or fail)
    # Cleanup for non-seeding regular tasks happens after on_download_complete
    # Seeding logic only applies to regular tasks as currently implemented

    # If it was an API task, cleanup now
    if is_api_task:
         LOGGER.info(f"API Task complete, initiating cleanup for Hash: {ext_hash}, Tag: {request_id}")
         await _remove_torrent(ext_hash, request_id)

    # Seeding logic for regular tasks (already handled above if seeding enabled)
    # Cleanup for non-seeding regular tasks (already handled above)


@new_task
async def _qb_listener():
    while True:
        async with qb_listener_lock:
            try:
                torrents = await sync_to_async(qbittorrent_client.torrents_info)
                if len(torrents) == 0:
                    intervals["qb"] = ""
                    break
                for tor_info in torrents:
                    tag = tor_info.tags
                    if tag not in qb_torrents:
                        continue
                    state = tor_info.state
                    if state == "metaDL":
                        qb_torrents[tag]["stalled_time"] = time()
                        if (
                            Config.TORRENT_TIMEOUT
                            and time() - qb_torrents[tag]["start_time"]
                            >= Config.TORRENT_TIMEOUT
                        ):
                            await _on_download_error("Dead Torrent!", tor_info)
                        else:
                            await sync_to_async(
                                qbittorrent_client.torrents_reannounce,
                                torrent_hashes=tor_info.hash,
                            )
                    elif state == "downloading":
                        qb_torrents[tag]["stalled_time"] = time()
                        if not qb_torrents[tag]["stop_dup_check"]:
                            qb_torrents[tag]["stop_dup_check"] = True
                            await _stop_duplicate(tor_info)
                    elif state == "stalledDL":
                        if (
                            not qb_torrents[tag]["rechecked"]
                            and 0.99989999999999999 < tor_info.progress < 1
                        ):
                            msg = f"Force recheck - Name: {tor_info.name} Hash: "
                            msg += f"{tor_info.hash} Downloaded Bytes: {tor_info.downloaded} "
                            msg += f"Size: {tor_info.size} Total Size: {tor_info.total_size}"
                            LOGGER.warning(msg)
                            await sync_to_async(
                                qbittorrent_client.torrents_recheck,
                                torrent_hashes=tor_info.hash,
                            )
                            qb_torrents[tag]["rechecked"] = True
                        elif (
                            Config.TORRENT_TIMEOUT
                            and time() - qb_torrents[tag]["stalled_time"]
                            >= Config.TORRENT_TIMEOUT
                        ):
                            await _on_download_error("Dead Torrent!", tor_info)
                        else:
                            await sync_to_async(
                                qbittorrent_client.torrents_reannounce,
                                torrent_hashes=tor_info.hash,
                            )
                    elif state == "missingFiles":
                        await sync_to_async(
                            qbittorrent_client.torrents_recheck,
                            torrent_hashes=tor_info.hash,
                        )
                    elif state == "error":
                        await _on_download_error(
                            "No enough space for this torrent on device", tor_info
                        )
                    elif (
                        tor_info.completion_on != -1
                        and not qb_torrents[tag]["uploaded"]
                        and state
                        not in ["checkingUP", "checkingDL", "checkingResumeData"]
                    ):
                        qb_torrents[tag]["uploaded"] = True
                        await _on_download_complete(tor_info)
                    elif (
                        state in ["stoppedUP", "stoppedDL"]
                        and qb_torrents[tag]["seeding"]
                    ):
                        qb_torrents[tag]["seeding"] = False
                        await _on_seed_finish(tor_info)
                        await sleep(0.5)
            except Exception as e:
                LOGGER.error(str(e))
        await sleep(3)

async def _send_webhook_notification(request_id, status, display_name, file_path=None, error_message=None, files=None, uploaded_to_chat_id=None, uploaded_message_link=None):
    if not getattr(Config, 'MAIN_BOT_WEBHOOK_URL', None):
        LOGGER.warning(f"MAIN_BOT_WEBHOOK_URL not configured. Cannot send notification for {request_id}.")
        return False

    api_request_data = await database.get_api_request(request_id)
    if not api_request_data:
        LOGGER.error(f"Could not find API request data in DB for request_id: {request_id}")
        return False

    payload = {
        "request_id": request_id,
        "status": status,
        "display_name": display_name,
        "original_chat_id": api_request_data['chat_id'],
        "original_message_id": api_request_data['message_id']
    }
    if status == "success":
        # We don't necessarily need file_path/files if main bot isn't accessing them
        # payload["file_path"] = file_path
        # payload["files"] = files if files else []
        payload["uploaded_to_chat_id"] = uploaded_to_chat_id # Add upload destination info
        if uploaded_message_link:
             payload["uploaded_message_link"] = uploaded_message_link # Add message link if available
    elif status == "failed":
        payload["error_message"] = str(error_message)

    headers = {"Content-Type": "application/json"}
    if getattr(Config, 'API_KEY', None):
         headers["X-API-Key"] = Config.API_KEY

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(Config.MAIN_BOT_WEBHOOK_URL, json=payload, headers=headers)
            if 200 <= response.status_code < 300:
                LOGGER.info(f"Successfully sent webhook notification for {request_id}. Status: {status}")
                await database.update_api_request_status(request_id, f"notified_{status}", error_message)
                return True
            else:
                LOGGER.error(f"Webhook notification failed for {request_id}. Status: {response.status_code}, Response: {response.text}")
                await database.update_api_request_status(request_id, f"notification_failed_{status}", f"Webhook Error {response.status_code}")
                return False
    except Exception as e:
        LOGGER.error(f"Error sending webhook for {request_id}: {e}", exc_info=True)
        await database.update_api_request_status(request_id, f"notification_failed_{status}", f"Webhook Exception: {e}")
        return False

# --- Modify _on_download_error ---
@new_task
async def _on_download_error(err, tor, button=None):
    request_id = tor.tags # Assuming tag is the request_id
    display_name = tor.name
    ext_hash = tor.hash
    is_api_task = False # Flag to check if it's an API task

    # Check if this task originated from the API by looking up the request_id in DB
    if request_id:
        api_request_data = await database.get_api_request(request_id)
        if api_request_data:
            is_api_task = True
            LOGGER.info(f"Download Error for API Task: {display_name} (Request ID: {request_id}), Error: {err}")
            # --- Call Webhook for API Task Failure ---
            await _send_webhook_notification(request_id, "failed", display_name, error_message=err)
            # --- End Webhook Call ---
        else:
             # Tag exists but not found in API DB - might be a regular task tag?
             LOGGER.info(f"Download Error for Task: {display_name} (Tag/Hash: {request_id or ext_hash}), Error: {err}")
    else:
        # No tag, likely a regular task identified by hash
        LOGGER.info(f"Download Error for Task: {display_name} (Hash: {ext_hash}), Error: {err}")


    # Original listener logic for tasks started via bot commands
    if not is_api_task:
        if task := await get_task_by_gid(ext_hash[:12]):
            await task.listener.on_download_error(err, button)

    # Cleanup qBittorrent and internal tracking (always do this on error)
    try:
        await sync_to_async(qbittorrent_client.torrents_pause, torrent_hashes=ext_hash)
        await sleep(0.5)
        # Use request_id as tag if available, otherwise fallback might be needed if tag wasn't set properly
        await _remove_torrent(ext_hash, request_id or f"error_{ext_hash}")
    except Exception as cleanup_err:
         LOGGER.error(f"Error during cleanup for errored task {ext_hash} (Tag: {request_id}): {cleanup_err}")


# --- Modify _on_download_complete ---
@new_task
async def _on_download_complete(tor):
    request_id = tor.tags # Assuming tag is the request_id
    display_name = tor.name
    ext_hash = tor.hash
    is_api_task = False
    api_request_data = None

    # Check if this task originated from the API
    if request_id:
        api_request_data = await database.get_api_request(request_id)
        if api_request_data:
            is_api_task = True
            LOGGER.info(f"Download Complete for API Task: {display_name} (Request ID: {request_id})")
        else:
            LOGGER.info(f"Download Complete for Task: {display_name} (Tag/Hash: {request_id or ext_hash})")
    else:
        LOGGER.info(f"Download Complete for Task: {display_name} (Hash: {ext_hash})")

    # --- Upload Logic ---
    upload_success = False
    upload_error = None
    uploaded_message_link = None
    upload_destination_chat_id = None

    if is_api_task:
        # API Task: Upload to designated channel
        upload_destination_chat_id = getattr(Config, 'UPLOAD_CHANNEL_ID', None)
        if not upload_destination_chat_id:
             upload_error = "UPLOAD_CHANNEL_ID not configured in Leech Bot."
             LOGGER.error(upload_error)
        else:
             try:
                  # We need to create a minimal listener-like object for the uploader
                  # Or modify the uploader to accept direct arguments
                  class ApiTaskListener: # Minimal class for uploader context
                       def __init__(self, user_id, request_id, name):
                            self.user_id = user_id
                            self.mid = request_id # Use request_id as message id substitute
                            self.name = name
                            self.is_cancelled = False # Assume not cancelled initially
                            self.is_super_chat = False # Assume uploading to a channel/group
                            self.up_dest = upload_destination_chat_id # Target chat
                            self.chat_thread_id = None # Set if needed
                            self.user_dict = {} # Empty user dict, apply defaults
                            self.thumb = None # Or load default thumb if configured
                            self.extension_filter = [] # Apply default filters if needed
                            self.user_transmission = False # Use bot client for upload
                            self.mixed_leech = False # Use bot client
                            self.as_doc = False # Default upload type
                            self.thumbnail_layout = None
                            self.screen_shots = 0

                       # Dummy methods if uploader calls them
                       async def on_upload_error(self, err): LOGGER.error(f"Uploader Error for {self.mid}: {err}")
                       async def on_upload_complete(self, link, files_dict, total_files, total_corrupt): pass # Listener handles completion

                  listener_for_upload = ApiTaskListener(api_request_data['user_id'], request_id, display_name)
                  uploader = TelegramUploader(listener=listener_for_upload, path=tor.content_path)
                  await uploader.upload() # Start the upload

                  # Check uploader status (needs modification in uploader to return status/link)
                  # For now, assume success if no exception, but ideally uploader returns info
                  # This part needs refinement based on how uploader signals completion/failure
                  if not listener_for_upload.is_cancelled and uploader._corrupted == 0: # Basic check
                       upload_success = True
                       # Try to get message link (needs uploader modification)
                       # uploaded_message_link = uploader.get_last_message_link()
                       LOGGER.info(f"Upload successful for API Task {request_id} to {upload_destination_chat_id}")
                  else:
                       upload_error = uploader._error or "Upload failed or was cancelled."
                       LOGGER.error(f"Upload failed for API Task {request_id}: {upload_error}")

             except Exception as e:
                  upload_error = f"Exception during upload: {e}"
                  LOGGER.error(f"Upload exception for API Task {request_id}: {e}", exc_info=True)

        # --- Send Webhook (Only for API tasks) ---
        if is_api_task:
             if upload_success:
                  await _send_webhook_notification(
                       request_id, "success", display_name,
                       uploaded_to_chat_id=upload_destination_chat_id,
                       uploaded_message_link=uploaded_message_link # Pass link if available
                  )
             else:
                  await _send_webhook_notification(
                       request_id, "failed", display_name,
                       error_message=f"Upload failed: {upload_error}"
                  )
        # --- End Webhook ---

    # --- Original Listener Logic (for non-API tasks) ---
    else:
        task = await get_task_by_gid(ext_hash[:12]) # Check if it was a bot task
        if task: # If it originated from a bot command, run original listener logic
             if not task.listener.seed:
                  await sync_to_async(qbittorrent_client.torrents_pause, torrent_hashes=ext_hash)
             if task.listener.select:
                  await clean_unwanted(task.listener.dir)
                  # ... (original file removal logic for select mode) ...
             await task.listener.on_download_complete() # This triggers the upload for regular tasks
             if intervals["stopAll"]: return
             # Seeding logic remains the same for regular tasks
             if task.listener.seed and not task.listener.is_cancelled:
                  # ... (original seeding logic) ...
                  pass
             else:
                  # Use tag if available, otherwise hash for cleanup
                  await _remove_torrent(ext_hash, request_id or task.listener.tag or ext_hash[:12])
        else:
             # Download complete but no associated task found (orphan?)
             LOGGER.warning(f"Orphan download completed. Hash: {ext_hash}, Tag: {request_id}. Cleaning up.")
             await _remove_torrent(ext_hash, request_id or ext_hash[:12]) # Cleanup orphan
             return # Stop processing orphan further

    # --- Seeding / Cleanup Logic (Adjusted) ---
    # This part needs careful review based on whether it was an API task or regular task

    # If it was a regular task and seeding is enabled:
    if task and task.listener.seed and not task.listener.is_cancelled:
         async with task_dict_lock:
              if task.listener.mid in task_dict:
                   removed = False
                   task_dict[task.listener.mid] = QbittorrentStatus(task.listener, True)
              else:
                   removed = True
         if removed:
              await _remove_torrent(ext_hash, request_id or task.listener.tag or ext_hash[:12])
              return
         async with qb_listener_lock:
              tag_to_check = request_id or task.listener.tag or ext_hash[:12]
              if tag_to_check in qb_torrents:
                   qb_torrents[tag_to_check]["seeding"] = True
              else:
                   # If tag wasn't added properly at start, this might fail. Add it now?
                   LOGGER.warning(f"Tag {tag_to_check} not found in qb_torrents for seeding start.")
                   # return # Or should we proceed?
         await update_status_message(task.listener.message.chat.id)
         LOGGER.info(f"Seeding started for regular task: {tor.name} - Hash: {ext_hash}")
    # If it was an API task OR a regular task without seeding OR seeding finished/cancelled:
    else:
         # Cleanup for API tasks happens after upload attempt (success or fail)
         # Cleanup for non-seeding regular tasks happens here
         LOGGER.info(f"Task complete, initiating cleanup for Hash: {ext_hash}, Tag: {request_id}")
         await _remove_torrent(ext_hash, request_id or (task.listener.tag if task else None) or ext_hash[:12])

# Make sure _remove_torrent uses the tag correctly
async def _remove_torrent(hash_, tag):
    try:
        await sync_to_async(
            qbittorrent_client.torrents_delete, torrent_hashes=hash_, delete_files=True
        )
        async with qb_listener_lock:
            if tag in qb_torrents:
                del qb_torrents[tag]
        # Don't delete tags if they might be reused or needed for other purposes?
        # Or ensure tags are unique per request (like request_id is)
        # await sync_to_async(qbittorrent_client.torrents_delete_tags, tags=tag) # Maybe skip this?
    except Exception as e:
        LOGGER.error(f"Error removing torrent {hash_} with tag {tag}: {e}")

# ... rest of the listener code (_qb_listener loop, on_download_start, etc.) ...
# Ensure on_download_start uses the tag correctly if called from add_qb_torrent

async def on_download_start(tag):
    async with qb_listener_lock:
        qb_torrents[tag] = {
            "start_time": time(),
            "stalled_time": time(),
            "stop_dup_check": False,
            "rechecked": False,
            "uploaded": False,
            "seeding": False,
        }
        if not intervals["qb"]:
            intervals["qb"] = await _qb_listener()

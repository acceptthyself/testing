from qbittorrentapi import Conflict409Error, APIConnectionError, Forbidden403Error
from aiofiles import open as aiopen
from aiofiles.os import remove, path as aiopath
from asyncio import sleep
from re import match as re_match
from time import time
from asyncio import sleep


from .... import (
    task_dict,
    task_dict_lock,
    qbittorrent_client,
    LOGGER,
)
from ....core.config_manager import Config
from ...ext_utils.bot_utils import bt_selection_buttons, sync_to_async
from ...ext_utils.task_manager import check_running_tasks
from .... import qb_listener_lock
from ...listeners.qbit_listener import on_download_start
from ...mirror_leech_utils.status_utils.qbit_status import QbittorrentStatus
from ...telegram_helper.message_utils import (
    send_message,
    delete_message,
    send_status_message,
)

"""
Only v1 torrents
#from hashlib import sha1
#from base64 import b16encode, b32decode
#from bencoding import bencode, bdecode
#from re import search as re_search
def _get_hash_magnet(mgt: str):
    hash_ = re_search(r'(?<=xt=urn:btih:)[a-zA-Z0-9]+', mgt).group(0)
    if len(hash_) == 32:
        hash_ = b16encode(b32decode(hash_.upper())).decode()
    return hash_

def _get_hash_file(fpath):
    with open(fpath, "rb") as f:
        decodedDict = bdecode(f.read())
        return sha1(bencode(decodedDict[b'info'])).hexdigest()
"""

# Helper function (ensure this exists or add it)
async def get_hash_from_magnet(magnet_uri):
    match = re_match(r'(?:^|&)xt=urn:btih:([^&/]+)', magnet_uri)
    return match.group(1).lower() if match else None


async def add_qb_torrent(magnet_uri, path, tag, select=False, seed=False, ratio=None, seed_time=None, torrent_file=None):
    """
    Adds a torrent to qBittorrent using direct parameters.
    Returns True on success, False on duplicate, raises Exception on other errors.
    """
    add_torrent_options = {}
    url_or_file_for_log = ""
    try:
        # Determine link/file (prioritize magnet_uri)
        if magnet_uri:
            url = magnet_uri
            url_or_file_for_log = url
            if await aiopath.exists(url): # Check if it's a local file path
                 torrent_file = url
                 url = None
        elif torrent_file:
             url = None
             url_or_file_for_log = torrent_file
             # Torrent file content will be read below
        else:
             raise ValueError("No valid magnet URI or torrent file provided.")

        if torrent_file:
             async with aiopen(torrent_file, "rb") as f:
                  torrent_content = await f.read()
             add_torrent_options["torrent_files"] = torrent_content
             if url: url = None # Prefer file if both somehow set
             LOGGER.info(f"qBittorrent using torrent file: {url_or_file_for_log}")
        elif url:
             add_torrent_options["urls"] = url
             LOGGER.info(f"qBittorrent using URL/Magnet: {url_or_file_for_log}")
        else:
             # This case should be caught by the initial check
             raise ValueError("No torrent data found after initial check.")

        add_torrent_options["save_path"] = path
        add_torrent_options["tags"] = tag # Use the provided tag

        # Apply options based on direct arguments
        if select:
            add_torrent_options["paused"] = "true" # Add paused to allow metadata download before starting
            add_torrent_options["sequential"] = True
            add_torrent_options["first_last_piece_prio"] = True
            LOGGER.info(f"Adding torrent paused for metadata check (select=True). Tag: {tag}")
        else:
             add_torrent_options["paused"] = "false"

        if seed:
            # qBittorrent uses -1 or -2 for ratio/time limits based on global settings
            # Use specific values if provided, otherwise rely on global settings
            if ratio is not None:
                add_torrent_options["ratio_limit"] = float(ratio)
            if seed_time is not None:
                # qBittorrent seeding_time_limit is in minutes
                add_torrent_options["seeding_time_limit"] = int(seed_time)
        else:
             # Force stop after download if not seeding
             add_torrent_options["ratio_limit"] = 0
             add_torrent_options["seeding_time_limit"] = 0


        # Add other options if needed, e.g., category based on tag?
        # add_torrent_options["category"] = f"api_cat_{tag}" # Example

        async with qb_listener_lock:
             # Use sync_to_async for the blocking API call
             await sync_to_async(qbittorrent_client.torrents_add, **add_torrent_options)

        LOGGER.info(f"Torrent add command sent to qBittorrent. Tag: {tag}")

        # Add to listener tracking (if tag is available)
        await on_download_start(tag) # Call the listener start function directly with the tag

        # Handle metadata download and pause if select=True
        if select:
             hash_ = None
             if url: # Magnet link
                  hash_ = await get_hash_from_magnet(url)
             elif torrent_file: # Torrent file - need to get hash after adding
                  # Wait a moment for qbit to process, then get info by tag
                  await sleep(2) # Small delay
                  try:
                       info = await sync_to_async(qbittorrent_client.torrents_info, tag=tag)
                       if info:
                            hash_ = info[0].hash
                       else:
                            LOGGER.warning(f"Could not find torrent by tag '{tag}' shortly after adding file to get hash for metadata check.")
                  except Exception as e:
                       LOGGER.error(f"Error getting torrent info by tag '{tag}' for metadata check: {e}")

             if hash_:
                  try:
                       await _check_metadata_and_pause(hash_, tag)
                       # If paused successfully, the listener will handle unpausing later if needed (e.g., via user action)
                       # Or, if you want auto-start after selection (not implemented here),
                       # the webhook would need to trigger an unpause.
                  except Exception as meta_err:
                       LOGGER.error(f"Metadata check/pause failed for tag {tag}: {meta_err}. Torrent might start automatically.")
                       # Decide how to handle this - maybe try to pause again?
                       try:
                            await sync_to_async(qbittorrent_client.torrents_pause, torrent_hashes=hash_)
                       except:
                            pass # Ignore error on secondary pause attempt
             else:
                  LOGGER.warning(f"Could not determine hash for tag '{tag}'. Cannot pause for metadata check.")


        return True # Indicate successful submission

    except Conflict409Error:
         LOGGER.info(f"Torrent already added: {url_or_file_for_log}")
         return False # Indicate duplicate
    except (APIConnectionError, Forbidden403Error) as e:
         LOGGER.error(f"qBittorrent API Error for tag {tag}: {e}", exc_info=True)
         raise e # Re-raise specific API errors
    except Exception as e:
         LOGGER.error(f"Generic error adding torrent with tag {tag}: {e}", exc_info=True)
         raise e # Re-raise other exceptions

async def get_hash_from_magnet(magnet_uri):
    match = re_match(r'xt=urn:btih:([^&/]+)', magnet_uri)
    return match.group(1).lower() if match else None

async def _check_metadata_and_pause(torrent_hash, tag):
    # Wait for metadata
    start_time = time()
    LOGGER.info(f"Metadata check: Waiting for metadata for hash {torrent_hash} (Tag: {tag})")
    while True:
        try:
            # Use sync_to_async for the blocking API call
            tor_info = await sync_to_async(qbittorrent_client.torrents_info, torrent_hashes=torrent_hash)
            if tor_info:
                tor_info = tor_info[0]
                state = tor_info.state
                # Check if metadata is available (state is not metaDL or checking)
                # Also check if it's pausedDL - might happen if added paused initially
                if state not in ["metaDL", "checkingUP", "checkingDL", "checkingResumeData", "allocating", "downloading"] or state == "pausedDL":
                    # Additional check to ensure files are listed (metadata is truly parsed)
                    files = await sync_to_async(qbittorrent_client.torrents_files, torrent_hashes=torrent_hash)
                    if files:
                        LOGGER.info(f"Metadata check: Metadata found for {torrent_hash}. Pausing.")
                        # Pause the torrent
                        await sync_to_async(qbittorrent_client.torrents_pause, torrent_hashes=torrent_hash)
                        # Optionally notify main bot that selection is ready? (Requires webhook call here - complex)
                        break
                    else:
                        LOGGER.debug(f"Metadata check: State is {state} but no files listed yet for {torrent_hash}. Waiting...")
                elif state == "error":
                     LOGGER.error(f"Metadata check: Torrent {torrent_hash} errored during metadata download.")
                     # Handle error - maybe raise exception?
                     raise Exception(f"Torrent errored during metadata download (State: {state})")
                else:
                    # Still downloading metadata or checking
                    LOGGER.debug(f"Metadata check: State is {state} for {torrent_hash}. Waiting...")
            else:
                 # Torrent might not be registered yet by qBittorrent, wait briefly
                 LOGGER.debug(f"Metadata check: Torrent info not found yet for {torrent_hash}. Waiting...")
                 pass
        except Exception as e:
            LOGGER.error(f"Metadata check: Error checking metadata for {torrent_hash}: {e}", exc_info=True)
            raise e # Re-raise error

        await sleep(2) # Check every 2 seconds
        if time() - start_time > 120: # Timeout for metadata (e.g., 2 minutes)
            LOGGER.warning(f"Metadata check: Metadata download timeout for {torrent_hash}")
            # Handle timeout - maybe raise exception?
            raise TimeoutError(f"Metadata download timed out for {torrent_hash}")

"""async def add_qb_torrent(listener, path, ratio, seed_time):
    try:
        url = listener.link
        tpath = None
        if await aiopath.exists(listener.link):
            url = None
            tpath = listener.link
        add_to_queue, event = await check_running_tasks(listener)
        op = await sync_to_async(
            qbittorrent_client.torrents_add,
            url,
            tpath,
            path,
            is_paused=add_to_queue,
            tags=f"{listener.mid}",
            ratio_limit=ratio,
            seeding_time_limit=seed_time,
        )
        if op.lower() == "ok.":
            tor_info = await sync_to_async(
                qbittorrent_client.torrents_info, tag=f"{listener.mid}"
            )
            if len(tor_info) == 0:
                while True:
                    if add_to_queue and event.is_set():
                        add_to_queue = False
                    tor_info = await sync_to_async(
                        qbittorrent_client.torrents_info, tag=f"{listener.mid}"
                    )
                    if len(tor_info) > 0:
                        break
                    await sleep(1)
            tor_info = tor_info[0]
            listener.name = tor_info.name
            ext_hash = tor_info.hash
        else:
            await listener.on_download_error(
                "This Torrent already added or unsupported/invalid link/file.",
            )
            return

        async with task_dict_lock:
            task_dict[listener.mid] = QbittorrentStatus(listener, queued=add_to_queue)
        await on_download_start(f"{listener.mid}")

        if add_to_queue:
            LOGGER.info(f"Added to Queue/Download: {tor_info.name} - Hash: {ext_hash}")
        else:
            LOGGER.info(f"QbitDownload started: {tor_info.name} - Hash: {ext_hash}")

        await listener.on_download_start()

        if Config.BASE_URL and listener.select:
            if listener.link.startswith("magnet:"):
                metamsg = "Downloading Metadata, wait then you can select files. Use torrent file to avoid this wait."
                meta = await send_message(listener.message, metamsg)
                while True:
                    tor_info = await sync_to_async(
                        qbittorrent_client.torrents_info, tag=f"{listener.mid}"
                    )
                    if len(tor_info) == 0:
                        await delete_message(meta)
                        return
                    try:
                        tor_info = tor_info[0]
                        if tor_info.state not in [
                            "metaDL",
                            "checkingResumeData",
                            "stoppedDL",
                        ]:
                            await delete_message(meta)
                            break
                    except:
                        await delete_message(meta)
                        return

            ext_hash = tor_info.hash
            if not add_to_queue:
                await sync_to_async(
                    qbittorrent_client.torrents_stop, torrent_hashes=ext_hash
                )
            SBUTTONS = bt_selection_buttons(ext_hash)
            msg = "Your download paused. Choose files then press Done Selecting button to start downloading."
            await send_message(listener.message, msg, SBUTTONS)
        elif listener.multi <= 1:
            await send_status_message(listener.message)

        if event is not None:
            if not event.is_set():
                await event.wait()
                if listener.is_cancelled:
                    return
                async with task_dict_lock:
                    task_dict[listener.mid].queued = False
                LOGGER.info(
                    f"Start Queued Download from Qbittorrent: {tor_info.name} - Hash: {ext_hash}"
                )
            await on_download_start(f"{listener.mid}")
            await sync_to_async(
                qbittorrent_client.torrents_start, torrent_hashes=ext_hash
            )

    except Exception as e:
        await listener.on_download_error(f"{e}")
    finally:
        if tpath and await aiopath.exists(tpath):
            await remove(tpath)"""

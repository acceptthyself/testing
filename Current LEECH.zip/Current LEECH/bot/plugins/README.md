# Search Plugins Directory

This directory contains search plugins for various torrent sites. Each plugin provides search functionality for a specific torrent site.

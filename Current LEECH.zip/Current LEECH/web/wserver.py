import time
import uuid
from bot.helper.ext_utils.bot_utils import sync_to_async # Might need this
# Assuming db_handler is accessible like this:
from bot.helper.ext_utils.db_handler import database
from bot.core.config_manager import Config # Import Config
# Import the function to add torrents (adjust path if needed)
from bot.helper.mirror_leech_utils.download_utils.qbit_download import add_qb_torrent
# Import a minimal listener or adapt add_qb_torrent
from bot.helper.listeners.task_listener import TaskListener # Base listener
import asyncio
# Remove duplicate time import if present
# import time

from aria2p import API as ariaAPI, Client as ariaClient
from flask import Flask, request, render_template, jsonify
from asgiref.wsgi import WsgiToAsgi # <<< IMPORT THIS
from logging import getLogger, FileHandler, StreamHandler, INFO, basicConfig
from qbittorrentapi import NotFound404Error, Client as qbClient
from time import sleep

from web.nodes import extract_file_ids, make_tree

app = Flask(__name__)

asgi_app = WsgiToAsgi(app)

qbittorrent_client = qbClient(
    host="localhost",
    port=8090,
    VERIFY_WEBUI_CERTIFICATE=False,
    REQUESTS_ARGS={"timeout": (30, 60)},
    HTTPADAPTER_ARGS={"pool_maxsize": 200, "pool_block": True},
)

aria2 = ariaAPI(ariaClient(host="http://localhost", port=6800, secret=""))

basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[FileHandler("log.txt"), StreamHandler()],
    level=INFO,
)

LOGGER = getLogger(__name__)


def re_verify(paused, resumed, hash_id):
    # ... (function remains the same) ...
    paused = paused.strip()
    resumed = resumed.strip()
    if paused:
        paused = paused.split("|")
    if resumed:
        resumed = resumed.split("|")

    k = 0
    while True:
        res = qbittorrent_client.torrents_files(torrent_hash=hash_id)
        verify = True
        for i in res:
            if str(i.id) in paused and i.priority != 0:
                verify = False
                break
            if str(i.id) in resumed and i.priority == 0:
                verify = False
                break
        if verify:
            break
        LOGGER.info("Reverification Failed! Correcting stuff...")
        sleep(1)
        try:
            qbittorrent_client.torrents_file_priority(
                torrent_hash=hash_id, file_ids=paused, priority=0
            )
        except NotFound404Error as e:
            raise NotFound404Error from e
        except Exception as e:
            LOGGER.error(f"{e} Errored in reverification paused!")
        try:
            qbittorrent_client.torrents_file_priority(
                torrent_hash=hash_id, file_ids=resumed, priority=1
            )
        except NotFound404Error as e:
            raise NotFound404Error from e
        except Exception as e:
            LOGGER.error(f"{e} Errored in reverification resumed!")
        k += 1
        if k > 5:
            return False
    LOGGER.info(f"Verified! Hash: {hash_id}")
    return True




async def _run_add_torrent_background(request_id, user_id, chat_id, message_id, listener_data, path, ratio, seed_time, magnet_uri, tag):
    """Wrapper to run the refactored add_qb_torrent in the background and handle errors."""
    db_added = False
    task_start_time = time.time()
    LOGGER.info(f"Background task started for request_id: {request_id} at {task_start_time}")
    try:
        # --- STEP 1: Add mapping to DB ---
        db_conn_start = time.time()
        if database.db is None: await database.connect()
        db_conn_dur = time.time() - db_conn_start
        LOGGER.info(f"BG Task {request_id}: DB connect check took {db_conn_dur:.4f}s")

        if database.db is not None:
            LOGGER.info(f"BG Task {request_id}: Attempting to add request to DB...")
            db_add_start = time.time()
            db_added = await database.add_api_request(request_id, user_id, chat_id, message_id)
            db_add_dur = time.time() - db_add_start
            if not db_added:
                 LOGGER.error(f"BG Task {request_id}: Failed to store request metadata in DB (took {db_add_dur:.4f}s). Aborting.")
                 return # Stop if we can't track it
            LOGGER.info(f"BG Task {request_id}: Successfully added request metadata to DB (took {db_add_dur:.4f}s).")
        else:
            LOGGER.error(f"BG Task {request_id}: DB connection unavailable. Aborting.")
            return # Stop if DB is down
        # --- End DB Add ---

        # --- STEP 2: Add torrent ---
        LOGGER.info(f"BG Task {request_id}: Calling refactored add_qb_torrent...")
        add_torrent_start = time.time()

        # Call the refactored function with direct arguments
        # Extract necessary data from listener_data or arguments
        success = await add_qb_torrent(
            magnet_uri=magnet_uri,
            path=path,
            tag=tag, # Use request_id as tag
            select=listener_data.get('select', False),
            seed=listener_data.get('seed', False),
            ratio=ratio, # Pass ratio if provided
            seed_time=seed_time # Pass seed_time if provided
            # torrent_file=None # Pass if handling file uploads via API later
        )
        add_torrent_dur = time.time() - add_torrent_start

        if success:
             LOGGER.info(f"BG Task {request_id}: add_qb_torrent call completed successfully (took {add_torrent_dur:.4f}s).")
        else:
             # add_qb_torrent handles logging Conflict, other errors are raised
             LOGGER.warning(f"BG Task {request_id}: add_qb_torrent reported non-success (e.g., duplicate) (took {add_torrent_dur:.4f}s).")
             # Update DB status to indicate duplicate or failure to add?
             if db_added and database.db is not None:
                  # Use a more specific status if possible, otherwise 'failed'
                  await database.update_api_request_status(request_id, "failed", "Duplicate torrent or failed before adding.")

        # --- End Add Torrent ---

        task_total_dur = time.time() - task_start_time
        # Only log overall success if add_qb_torrent didn't raise an exception
        # The 'success' variable here only indicates non-duplicate submission
        LOGGER.info(f"Background task finished for request_id: {request_id} in {task_total_dur:.4f}s (Torrent submission attempted).")

    except Exception as e:
        # Catch errors raised by add_qb_torrent or other issues
        task_total_dur = time.time() - task_start_time
        LOGGER.error(f"Background task failed for request_id: {request_id} after {task_total_dur:.4f}s: {e}", exc_info=True)
        try:
            # Update DB status to failed
            if db_added and database.db is not None:
                 await database.update_api_request_status(request_id, "failed", f"Error adding task: {e}")
            elif database.db is None:
                 LOGGER.error(f"DB connection unavailable, cannot update status for failed background task {request_id}")
        except Exception as db_err:
            LOGGER.error(f"Failed to update DB status for failed background task {request_id}: {db_err}")

# ... (rest of wserver.py, including handle_leech_request which remains unchanged from the last version) ...

# Existing routes (remain the same)
@app.route("/app/files")
def files():
    # ... (function remains the same) ...
    return render_template("page.html")

@app.route("/app/files/torrent", methods=["GET", "POST"])
def handle_torrent():
    # ... (function remains the same) ...
    return jsonify(content)

def handle_rename(gid, data):
    # ... (function remains the same) ...
    pass

def set_qbittorrent(gid, selected_files, unselected_files):
    # ... (function remains the same) ...
    pass

def set_aria2(gid, selected_files):
    # ... (function remains the same) ...
    pass

@app.route("/")
def homepage():
    # ... (function remains the same) ...
    return "<h1>See mirror-leech-telegram-bot <a href='https://www.github.com/anasty17/mirror-leech-telegram-bot'>@GitHub</a> By <a href='https://github.com/anasty17'>Anas</a></h1>"

@app.errorhandler(Exception)
def page_not_found(e):
    # ... (function remains the same) ...
    return (
        f"<h1>404: Task not found! Mostly wrong input. <br><br>Error: {e}</h2>",
        404,
    )

# --- EDITED API ENDPOINT ---
@app.route('/api/v1/leech/qbittorrent', methods=['POST'])
async def handle_leech_request():
    request_id = None # Initialize request_id as None early on
    start_time = time.time() # Start timing early
    try:
        # 1. Authentication
        api_key = request.headers.get('X-API-Key')
        if not api_key or api_key != getattr(Config, 'API_KEY', None):
             LOGGER.error("API Key Mismatch or Missing")
             return jsonify({"status": "error", "message": "Unauthorized"}), 401

        # 2. Validate Payload
        data = request.json
        if not data:
            LOGGER.warning("API request received without JSON payload.")
            return jsonify({"status": "error", "message": "No JSON payload"}), 400
        # --- ADD DEBUG PRINT FOR RECEIVED DATA ---
        LOGGER.debug(f"DEBUG: Received data payload: {data}")

        required_fields = ["magnet_link", "request_id", "user_id", "original_chat_id", "original_message_id"]
        if not all(field in data for field in required_fields):
            missing = [field for field in required_fields if field not in data]
            LOGGER.warning(f"API request missing required fields: {', '.join(missing)}")
            return jsonify({"status": "error", "message": f"Missing fields: {', '.join(missing)}"}), 400

        # --- Assign variables *within a try block* for precise error catching ---
        try:
            magnet_link = data['magnet_link']
            request_id = data['request_id'] # Assign the actual request_id now
            user_id = data['user_id'] # <<< This is where KeyError might happen
            original_chat_id = data['original_chat_id']
            original_message_id = data['original_message_id']
            display_name = data.get('display_name', 'N/A')
            is_leech = data.get('is_leech', True)
            ratio = data.get('ratio')
            seed_time = data.get('seed_time')
            LOGGER.debug(f"DEBUG: Variables assigned successfully for request {request_id}")
        except KeyError as ke:
            # Log the specific key error and return 400
            LOGGER.error(f"KeyError during variable assignment: Missing key {ke} in payload: {data}", exc_info=True)
            return jsonify({"status": "error", "message": f"Missing required key in payload: {ke}"}), 400
        except Exception as assign_err:
            # Catch any other unexpected error during assignment
            LOGGER.error(f"Error during variable assignment: {assign_err}", exc_info=True)
            return jsonify({"status": "error", "message": "Error processing payload data."}), 500
        # --- End variable assignment ---

        # --- If we reach here, all required variables including user_id are assigned ---
        LOGGER.info(f"API Request Received: ID={request_id}, User={user_id}, Name={display_name}") # This should now work

        # --- Database connection check ---
        LOGGER.info(f"API Request {request_id}: Checking database connection status...")
        if database.db is None:
            LOGGER.warning(f"API Request {request_id}: Database object is None. Attempting connection...")
            connect_start_time = time.time()
            await database.connect()
            connect_duration = time.time() - connect_start_time
            LOGGER.info(f"API Request {request_id}: database.connect() took {connect_duration:.4f} seconds.")
            if database.db is None:
                LOGGER.error(f"API Request {request_id}: Database connection failed after attempt.")
                return jsonify({"status": "error", "message": "Leech bot database unavailable"}), 503
            else:
                LOGGER.info(f"API Request {request_id}: Database connection successful after explicit connect call.")
        else:
            LOGGER.info(f"API Request {request_id}: Database object already exists.")
        # --- End Database connection check ---

        # --- Schedule Background Task ---
        LOGGER.info(f"API Request {request_id}: Scheduling background task...")
        schedule_start = time.time()
        listener_data = {
            'mid': request_id, 'uid': user_id, 'is_leech': is_leech,
            'select': data.get('select', False), 'seed': bool(ratio or seed_time),
            'tag': f"api_{user_id}"
        }
        download_path = f"{Config.DOWNLOAD_DIR}{request_id}"
        loop = asyncio.get_running_loop()
        loop.create_task(
            _run_add_torrent_background(
                request_id=request_id, user_id=user_id, chat_id=original_chat_id, message_id=original_message_id,
                listener_data=listener_data, path=download_path,
                ratio=ratio, seed_time=seed_time, magnet_uri=magnet_link, tag=request_id
            )
        )
        schedule_duration = time.time() - schedule_start
        LOGGER.info(f"API Request {request_id}: Scheduling took {schedule_duration:.4f} seconds.")
        # --- End Schedule Background Task ---

        # --- Return Success ---
        total_time = time.time() - start_time
        LOGGER.info(f"API Request {request_id}: Handler finished before return in {total_time:.4f} seconds.")
        LOGGER.info(f"API Request {request_id}: Returning 202 Accepted.")
        return jsonify({"status": "success", "message": "Download task scheduled", "request_id": request_id}), 202
        # --- End Return Success ---

    except Exception as e:
        # --- Keep the generic error handling block ---
        error_log_msg = f"Unhandled error processing API request"
        if request_id: # Check if request_id was assigned before the error
            error_log_msg += f" (ID: {request_id})"
        error_log_msg += f": {e}"
        LOGGER.error(error_log_msg, exc_info=True)

        if request_id and hasattr(database, 'db') and database.db is not None:
            try:
                await database.update_api_request_status(request_id, "failed", f"Unhandled error: {e}")
            except Exception as db_err:
                LOGGER.error(f"Failed to update DB status for failed request {request_id} after unhandled error: {db_err}")
        elif request_id:
             LOGGER.warning(f"Cannot update DB status for failed request {request_id}: DB object not available or not connected.")

        return jsonify({"status": "error", "message": "Internal server error processing request."}), 500
        # --- End generic error handling block ---


if __name__ == "__main__":
    try:
        import uvicorn
        # Run the wrapped 'asgi_app' with uvicorn
        uvicorn.run(asgi_app, host='0.0.0.0', port=8080, log_level="info")
    except ImportError:
        # Fallback to Flask's development server if uvicorn isn't installed locally
        app.run(host='0.0.0.0', port=8080)